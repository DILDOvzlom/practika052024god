﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.DataFiles
{
    class OdbConnect
    /// <summary>
    /// Статическое поле для доступа к объекту банcumматEntities.
    /// Винник Игорь Андреевич
    /// 15.02.2024
    /// </summary>
    {
        public static банcumматEntities entObj;
    }
}
