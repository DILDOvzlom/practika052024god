﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.Pages;
using WpfApp1.DataFiles;

namespace WpfApp1.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageMenu.xaml
    /// </summary>
    public partial class PageMenu : Page
    {
        /// <summary>
        /// Инициализирует новый экземпляр класса PageMenu.
        /// Винник Игорь Андреевич
        /// 13.02.2024
        /// </summary>
        public PageMenu()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Обработчик события нажатия кнопки.
        /// (Неполный - отсутствует код)
        /// Винник Игорь Андреевич
        /// 13.02.2024
        /// </summary>
        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
        /// <summary>
        /// Обработчик события нажатия кнопки "Налик".
        /// Переходит на страницу PageNalik.
        /// Винник Игорь Андреевич
        /// 13.02.2024
        /// </summary>
        private void nalik_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageNalik());
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "Справка".
        /// Переходит на страницу PageSpravka.
        /// Винник Игорь Андреевич
        /// 13.02.2024
        /// </summary>
        private void spravka_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageSpravka());
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "Блок".
        /// Переходит на страницу PageBlock.
        /// Винник Игорь Андреевич
        /// 13.02.2024
        /// </summary>
        private void block_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageBlock());
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "Назад".
        /// Переходит на страницу PageLogin.
        /// Винник Игорь Андреевич
        /// 13.02.2024
        /// </summary>
        private void back_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageLogin());
        }
    }
}
