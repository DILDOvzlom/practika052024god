﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.DataFiles;
using WpfApp1.Pages;

namespace WpfApp1.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageLogin.xaml
    /// </summary>
    public partial class PageLogin : Page
    {
       /// <summary>
       /// Инициализирует новый экземпляр класс PageLogin
       /// </summary>
       ///13.02.2024
       ///Винник Игорь Андреевич
        
        public PageLogin()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "1".
        /// Добавляет цифру "1" в текстовое поле tbPin.
        ///13.02.2024
        ///Винник Игорь Андреевич
        /// </summary>
        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            tbPin.Text += "1";
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "2".
        /// Добавляет цифру "2" в текстовое поле tbPin.
        ///13.02.2024
        ///Винник Игорь Андреевич
        /// </summary>
        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            tbPin.Text += "2";
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "3".
        /// Добавляет цифру "3" в текстовое поле tbPin.
        ///13.02.2024
        ///Винник Игорь Андреевич
        /// </summary>
        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            tbPin.Text += "3";
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "4".
        /// Добавляет цифру "4" в текстовое поле tbPin.
        ///13.02.2024
        ///Винник Игорь Андреевич
        /// </summary>
        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            tbPin.Text += "4";
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "5".
        /// Добавляет цифру "5" в текстовое поле tbPin.
        ///13.02.2024
        ///Винник Игорь Андреевич
        /// </summary>
        private void btn5_Click(object sender, RoutedEventArgs e)
        {
            tbPin.Text += "5";
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "6".
        /// Добавляет цифру "6" в текстовое поле tbPin.
        ///13.02.2024
        ///Винник Игорь Андреевич
        /// </summary>
        private void btn6_Click(object sender, RoutedEventArgs e)
        {
            tbPin.Text += "6";
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "7".
        /// Добавляет цифру "7" в текстовое поле tbPin.
        ///13.02.2024
        ///Винник Игорь Андреевич
        /// </summary>
        private void btn7_Click(object sender, RoutedEventArgs e)
        {
            tbPin.Text += "7";
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "8".
        /// Добавляет цифру "8" в текстовое поле tbPin.
        ///13.02.2024
        ///Винник Игорь Андреевич
        /// </summary>
        private void btn8_Click(object sender, RoutedEventArgs e)
        {
            tbPin.Text += "8";
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "9".
        /// Добавляет цифру "9" в текстовое поле tbPin.
        ///13.02.2024
        ///Винник Игорь Андреевич
        /// </summary>
        private void btn9_Click(object sender, RoutedEventArgs e)
        {
            tbPin.Text += "9";
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "0".
        /// Добавляет цифру "0" в текстовое поле tbPin.
        ///13.02.2024
        ///Винник Игорь Андреевич
        /// </summary>
        private void btn0_Click(object sender, RoutedEventArgs e)
        {
            tbPin.Text += "0";
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "OK".
        /// Проверяет правильность введенного PIN-кода.
        /// Переходит на страницу PageMenu, если PIN-код равен "1234".
        /// Отображает сообщение об ошибке, если PIN-код неверный.
        ///13.02.2024
        ///Винник Игорь Андреевич
        /// </summary>
        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if (tbPin.Text == "1234")
            {
                FrameApp.frmObj.Navigate(new PageMenu());
            }
            else
            {
                MessageBox.Show("Ты ввел не те данные для отпрвки в дарк нет гдЕ CVV КОД!");
            }
        }

        /// <summary>
        /// Обработчик события нажатия кнопки "Очистить".
        /// Очищает текстовое поле tbPin.
        ///13.02.2024
        ///Винник Игорь Андреевич
        /// </summary>
        private void btnC_Click(object sender, RoutedEventArgs e)
        {
            tbPin.Clear();
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "Назад".
        /// (Неполный - отсутствует код)
        ///13.02.2024
        ///Винник Игорь Андреевич
        /// </summary>
        private void back_Click(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
