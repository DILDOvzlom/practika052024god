﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.DataFiles;
using WpfApp1.Pages;

namespace WpfApp1.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageNalik.xaml
    /// </summary>
    public partial class PageNalik : Page
    {
        /// <summary>
        /// Инициализирует новый экземпляр класса PageNalik.
        /// Винник Игорь Андреевич
        /// 13.02.2024
        /// </summary>
        public PageNalik()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "Назад".
        /// Винник Игорь Андреевич
        /// 13.02.2024
        /// </summary>
        private void back_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageMenu());
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
