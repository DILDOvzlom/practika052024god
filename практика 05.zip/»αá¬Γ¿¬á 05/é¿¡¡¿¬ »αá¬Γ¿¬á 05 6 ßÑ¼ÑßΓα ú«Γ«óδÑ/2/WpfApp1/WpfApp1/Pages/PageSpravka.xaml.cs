﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.DataFiles;

namespace WpfApp1.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageSpravka.xaml
    /// </summary>
    public partial class PageSpravka : Page
    {
        
        public PageSpravka()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Инициализирует новый экземпляр класса PageSpravka.
        /// Винник Игорь Андреевич 
        /// 13.02.2024
        /// </summary>
        private void back_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageMenu());
        }
        /// <summary>
        /// Обработчик события нажатия кнопки "Налик".
        /// (Неполный - отсутствует код)
        /// Винник Игорь Андреевич 
        /// 13.02.2024
        /// </summary>
        private void nalik_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
